'use client'

import { useState } from 'react'

interface NavigationProps {
  currentPage: string
  onNavigate: (page: string) => void
}

export default function Navigation({ currentPage, onNavigate }: NavigationProps) {
  const navItems = [
    { id: 'home', label: 'Home', icon: '🏠' },
    { id: 'verify', label: 'Verify', icon: '✓' },
    { id: 'submit', label: 'Report', icon: '+' },
    { id: 'reputation', label: 'Profile', icon: '👤' },
    { id: 'moderate', label: 'Moderate', icon: '⚖️' },
  ]

  return (
    <nav className="sticky top-0 z-50 bg-card/95 border-b border-border/50 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-3 hover:opacity-80 transition group"
          >
            <div className="text-3xl font-black bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              ⚡
            </div>
            <div className="flex flex-col leading-tight">
              <span className="text-xl font-black bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent tracking-tight">
                TRUTHLINE
              </span>
              <span className="text-xs text-muted-foreground font-bold uppercase tracking-widest">Decentralized Truth</span>
            </div>
          </button>

          <div className="hidden md:flex items-center gap-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`px-4 py-2 rounded-xl font-bold transition-all duration-300 uppercase text-xs tracking-wide ${
                  currentPage === item.id
                    ? 'bg-gradient-to-r from-primary to-accent text-primary-foreground shadow-lg shadow-primary/30 scale-105'
                    : 'text-foreground hover:bg-primary/10 hover:scale-105'
                }`}
              >
                <span className="mr-1.5">{item.icon}</span>
                {item.label}
              </button>
            ))}
          </div>

          {/* Mobile Menu */}
          <div className="md:hidden flex items-center gap-2">
            {navItems.slice(1, 3).map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`p-2 rounded-lg transition ${
                  currentPage === item.id ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'
                }`}
                title={item.label}
              >
                {item.icon}
              </button>
            ))}
          </div>
        </div>
      </div>
    </nav>
  )
}
