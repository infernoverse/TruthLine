'use client'

import { useState, useEffect } from 'react'

interface ModerationPanelProps {
  onNavigate: (page: string) => void
}

interface Claim {
  id: string
  content: string
  source: string
  category: string
  submittedAt: number
  submittedBy: string
}

interface Flag {
  claimId: string
  reason: string
  count: number
}

export default function ModerationPanel({ onNavigate }: ModerationPanelProps) {
  const [claims, setClaims] = useState<Claim[]>([])
  const [flags, setFlags] = useState<Record<string, Flag>>({})
  const [selectedClaim, setSelectedClaim] = useState<string | null>(null)
  const [action, setAction] = useState<'approve' | 'remove' | null>(null)

  useEffect(() => {
    const claimsData = JSON.parse(localStorage.getItem('claims') || '[]')
    const flagsData = JSON.parse(localStorage.getItem('flaggedClaims') || '{}')
    setClaims(claimsData)
    setFlags(flagsData)
  }, [])

  const handleFlag = (claimId: string, reason: string) => {
    const updatedFlags = { ...flags }
    updatedFlags[claimId] = {
      claimId,
      reason,
      count: (updatedFlags[claimId]?.count || 0) + 1,
    }
    setFlags(updatedFlags)
    localStorage.setItem('flaggedClaims', JSON.stringify(updatedFlags))
  }

  const handleModAction = (claimId: string, actionType: 'approve' | 'remove') => {
    if (actionType === 'remove') {
      setClaims(claims.filter((c) => c.id !== claimId))
      const updated = claims.filter((c) => c.id !== claimId)
      localStorage.setItem('claims', JSON.stringify(updated))
    }
    const updatedFlags = { ...flags }
    delete updatedFlags[claimId]
    setFlags(updatedFlags)
    localStorage.setItem('flaggedClaims', JSON.stringify(updatedFlags))
    setSelectedClaim(null)
    setAction(null)
  }

  const flaggedClaims = Object.values(flags)

  return (
    <div className="py-8">
      <h1 className="text-3xl font-bold mb-8">Moderation Panel</h1>

      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <div className="bg-card p-6 rounded-lg border border-border">
          <div className="text-3xl font-bold text-primary mb-2">{Object.keys(flags).length}</div>
          <div className="text-sm text-muted-foreground">Flagged Claims</div>
        </div>
        <div className="bg-card p-6 rounded-lg border border-border">
          <div className="text-3xl font-bold text-yellow-600 mb-2">
            {Object.values(flags).reduce((sum, f) => sum + f.count, 0)}
          </div>
          <div className="text-sm text-muted-foreground">Total Flags</div>
        </div>
        <div className="bg-card p-6 rounded-lg border border-border">
          <div className="text-3xl font-bold text-blue-600 mb-2">{claims.length}</div>
          <div className="text-sm text-muted-foreground">Active Claims</div>
        </div>
      </div>

      {flaggedClaims.length === 0 ? (
        <div className="text-center py-12 bg-card rounded-lg border border-border">
          <p className="text-muted-foreground">No flagged claims to review.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {flaggedClaims.map((flag) => {
            const claim = claims.find((c) => c.id === flag.claimId)
            return (
              <div key={flag.claimId} className="bg-card p-6 rounded-lg border border-border">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <p className="text-sm text-muted-foreground mb-2">
                      {claim?.submittedBy} · {claim?.category}
                    </p>
                    <p className="text-lg leading-relaxed">{claim?.content}</p>
                  </div>
                  <span className="ml-4 px-3 py-1 bg-yellow-100 dark:bg-yellow-900 text-yellow-900 dark:text-yellow-100 rounded-full text-sm font-semibold">
                    {flag.count} {flag.count === 1 ? 'flag' : 'flags'}
                  </span>
                </div>

                <div className="mb-4 p-3 bg-muted rounded-lg">
                  <p className="text-sm font-semibold mb-1">Flag Reason:</p>
                  <p className="text-sm text-muted-foreground">{flag.reason}</p>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => handleModAction(flag.claimId, 'approve')}
                    className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium transition"
                  >
                    Approve
                  </button>
                  <button
                    onClick={() => handleModAction(flag.claimId, 'remove')}
                    className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition"
                  >
                    Remove
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
