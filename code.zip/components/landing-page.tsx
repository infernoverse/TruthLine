'use client'

import { useState, useEffect } from 'react'

interface LandingPageProps {
  onNavigate: (page: string) => void
}

export default function LandingPage({ onNavigate }: LandingPageProps) {
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <main className="overflow-hidden">
      <section className="relative min-h-screen bg-background flex items-center overflow-hidden">
        {/* Dynamic gradient background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/30 rounded-full blur-3xl opacity-60" />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-secondary/20 rounded-full blur-3xl opacity-60" />
          <div className="absolute top-1/2 right-0 w-96 h-96 bg-accent/20 rounded-full blur-3xl opacity-40" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="animate-float-in space-y-6">
              <div>
                <h1 className="text-6xl md:text-7xl lg:text-8xl font-black text-balance leading-none tracking-tight mb-6">
                  <span className="text-foreground">RECLAIM</span>
                  <br />
                  <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                    TRUTH
                  </span>
                </h1>
                <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-lg">
                  In an age where misinformation spreads faster than lightning, TruthLine empowers communities to expose fake news and collaboratively verify content. Decentralized. Transparent. Unstoppable.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <button
                  onClick={() => onNavigate('verify')}
                  className="px-8 py-4 bg-gradient-to-r from-primary to-accent text-primary-foreground rounded-xl font-bold hover:shadow-lg hover:shadow-primary/40 transition-all duration-300 uppercase text-sm tracking-wide hover:scale-105 active:scale-95"
                >
                  ✓ Start Verifying
                </button>
                <button
                  onClick={() => onNavigate('submit')}
                  className="px-8 py-4 border-2 border-primary text-primary rounded-xl font-bold hover:bg-primary/5 transition-all duration-300 uppercase text-sm tracking-wide hover:scale-105 active:scale-95"
                >
                  ⚠️ Report Fake News
                </button>
              </div>

              <div className="flex items-center gap-6 pt-4 animate-slide-in-right">
                <div className="flex -space-x-3">
                  {[0, 1, 2].map((i) => (
                    <div key={i} className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/30 to-secondary/30 border-3 border-background flex items-center justify-center text-lg font-bold animate-badge-pop" style={{ animationDelay: `${i * 0.1}s` }}>
                      👤
                    </div>
                  ))}
                </div>
                <div>
                  <p className="text-sm font-bold text-foreground">2,847 verifiers fighting</p>
                  <p className="text-xs text-muted-foreground">misinformation right now</p>
                </div>
              </div>
            </div>
          </div>

          <div className="relative hidden md:block">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-2xl blur-2xl" />
              <div className="relative glass rounded-2xl p-1 border border-primary/30">
                <div className="bg-gradient-to-br from-background to-card rounded-xl p-8 space-y-6">
                  <div className="space-y-4">
                    <div className="h-4 bg-gradient-to-r from-primary/30 to-secondary/30 rounded-full w-3/4 animate-pulse" />
                    <div className="h-4 bg-muted rounded-full w-full animate-pulse" style={{ animationDelay: '0.1s' }} />
                    <div className="h-4 bg-muted rounded-full w-5/6 animate-pulse" style={{ animationDelay: '0.2s' }} />
                  </div>
                  <div className="flex gap-3 pt-4">
                    <div className="h-10 bg-gradient-to-r from-primary/40 to-primary/20 rounded-lg flex-1 animate-pulse" />
                    <div className="h-10 bg-gradient-to-r from-secondary/40 to-secondary/20 rounded-lg flex-1 animate-pulse" />
                    <div className="h-10 bg-gradient-to-r from-accent/40 to-accent/20 rounded-lg flex-1 animate-pulse" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background to-card">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20 space-y-4">
            <h2 className="text-5xl md:text-6xl font-black text-balance tracking-tight">
              Why Truth <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Matters Now</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Misinformation erodes trust, polarizes communities, and threatens informed decision-making. TruthLine transforms passive readers into active truth-seekers.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: '🌍', title: 'Decentralized Power', desc: 'No single entity controls truth. Crowdsourced verification ensures diverse perspectives.' },
              { icon: '🔗', title: 'Community Trust', desc: 'Build reputation through accurate verifications. High-trust members gain influence.' },
              { icon: '📊', title: 'Transparent Metrics', desc: 'See exactly how claims are verified. All calculations shown transparently.' }
            ].map((item, idx) => (
              <div key={idx} className="group p-8 bg-card rounded-2xl border border-border hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/10 hover:scale-105">
                <div className="text-5xl mb-4 group-hover:scale-125 transition-transform duration-300">{item.icon}</div>
                <h3 className="text-2xl font-black mb-3 text-foreground">{item.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-background">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-black text-balance mb-20 text-center tracking-tight">
            How <span className="bg-gradient-to-r from-secondary to-primary bg-clip-text text-transparent">TruthLine</span> Works
          </h2>

          <div className="grid md:grid-cols-2 gap-16 items-start">
            <div className="space-y-8">
              {[
                { step: 1, title: 'Report a Claim', desc: 'Found misinformation? Submit with source and context.' },
                { step: 2, title: 'Community Reviews', desc: 'Thousands assess the claim. Vote: verified, disputed, or false.' },
                { step: 3, title: 'Trust Score Emerges', desc: 'Votes calculate automatically. Claims marked by consensus.' },
                { step: 4, title: 'Moderation & Reputation', desc: 'High-reputation users moderate. Bad actors flagged.' }
              ].map((item, idx) => (
                <div key={idx} className="flex gap-4 group">
                  <div className="flex-shrink-0">
                    <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-primary to-accent text-primary-foreground font-black text-lg group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-primary/30">
                      {item.step}
                    </div>
                  </div>
                  <div className="flex-1 pt-1">
                    <h4 className="text-xl font-bold mb-2 text-foreground">{item.title}</h4>
                    <p className="text-muted-foreground leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="glass rounded-2xl p-8 border border-primary/30 space-y-6 h-fit sticky top-24">
              <div>
                <p className="text-sm font-bold text-primary uppercase tracking-widest mb-3">Example Claim</p>
                <h3 className="text-xl font-black text-foreground mb-4">Climate change is a hoax</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs font-bold">
                    <span className="text-muted-foreground">VERIFICATION STATUS</span>
                  </div>
                  <div className="flex h-3 gap-1 rounded-full overflow-hidden bg-muted">
                    <div className="bg-green-500 flex-[0.7] rounded-full" />
                    <div className="bg-blue-500 flex-[0.2] rounded-full" />
                    <div className="bg-red-500 flex-[0.1] rounded-full" />
                  </div>
                  <div className="flex justify-between text-xs font-bold pt-2">
                    <span className="text-green-600">✓ 70% Verified</span>
                    <span className="text-blue-600">≈ 20% Disputed</span>
                    <span className="text-red-600">✗ 10% False</span>
                  </div>
                  <p className="text-sm font-bold text-green-600 bg-green-500/10 px-3 py-2 rounded-lg border border-green-500/30 mt-4">
                    ✓ VERIFIED (with nuance)
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-card">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-black text-balance mb-20 text-center tracking-tight">
            Platform <span className="bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">Features</span>
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: '📊', title: 'Trust Scoring', desc: 'Automatic calculations show credibility at a glance' },
              { icon: '👥', title: 'Peer Moderation', desc: 'Community members review and moderate content' },
              { icon: '⭐', title: 'Reputation System', desc: 'Earn points for accurate verifications' },
              { icon: '🏆', title: 'Achievement Tiers', desc: 'Unlock status: Verifier → Expert → Moderator' },
              { icon: '🔍', title: 'Transparent Votes', desc: 'See voting breakdown for every claim' },
              { icon: '🛡️', title: 'Abuse Prevention', desc: 'Anti-spam and bad-faith actor detection' }
            ].map((feature, idx) => (
              <div key={idx} className="group p-6 bg-background rounded-2xl border border-border hover:border-accent/50 transition-all duration-300 hover:shadow-lg hover:shadow-accent/20 hover:scale-105 cursor-pointer">
                <div className="text-4xl mb-4 group-hover:scale-125 group-hover:rotate-12 transition-all duration-300">{feature.icon}</div>
                <h3 className="font-black text-lg mb-2 text-foreground">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-primary/10 via-accent/10 to-secondary/10 relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-1/2 -right-1/2 w-full h-full bg-gradient-to-bl from-primary/20 to-transparent rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-4xl mx-auto text-center space-y-10">
          <div>
            <h2 className="text-5xl md:text-6xl lg:text-7xl font-black text-balance mb-6 tracking-tight">
              Join the <span className="bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">Truth Movement</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Every verification matters. Every voice strengthens truth. Start making a difference today.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <button
              onClick={() => onNavigate('verify')}
              className="px-8 py-4 bg-gradient-to-r from-primary to-accent text-primary-foreground rounded-xl font-black hover:shadow-2xl hover:shadow-primary/40 transition-all duration-300 uppercase text-sm tracking-wide hover:scale-105 active:scale-95 text-lg"
            >
              ✓ Start Verifying Now
            </button>
            <button
              onClick={() => onNavigate('submit')}
              className="px-8 py-4 border-2 border-primary text-primary rounded-xl font-black hover:bg-primary/10 transition-all duration-300 uppercase text-sm tracking-wide hover:scale-105 active:scale-95 text-lg"
            >
              ⚠️ Report Misinformation
            </button>
          </div>
        </div>
      </section>
    </main>
  )
}
