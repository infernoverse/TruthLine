'use client'

import { useState, useEffect } from 'react'
import ClaimCard from '@/components/claim-card'

interface VerifyClaimsPageProps {
  onNavigate: (page: string) => void
}

interface Claim {
  id: string
  content: string
  source: string
  category: string
  submittedAt: number
  submittedBy: string
}

interface Vote {
  claimId: string
  verified: number
  disputed: number
  false: number
}

export default function VerifyClaimsPage({ onNavigate }: VerifyClaimsPageProps) {
  const [claims, setClaims] = useState<Claim[]>([])
  const [votes, setVotes] = useState<Record<string, Vote>>({})
  const [filter, setFilter] = useState('all')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const claimsData = JSON.parse(localStorage.getItem('claims') || '[]')
    const votesData = JSON.parse(localStorage.getItem('votes') || '{}')
    setClaims(claimsData.sort((a: Claim, b: Claim) => b.submittedAt - a.submittedAt))
    setVotes(votesData)
    setLoading(false)
  }, [])

  const handleVote = (claimId: string, voteType: 'verified' | 'disputed' | 'false') => {
    const updatedVotes = { ...votes }
    if (!updatedVotes[claimId]) {
      updatedVotes[claimId] = { claimId, verified: 0, disputed: 0, false: 0 }
    }
    updatedVotes[claimId][voteType]++
    setVotes(updatedVotes)
    localStorage.setItem('votes', JSON.stringify(updatedVotes))
  }

  const getStatus = (claimId: string) => {
    const vote = votes[claimId]
    if (!vote || (vote.verified === 0 && vote.disputed === 0 && vote.false === 0)) {
      return 'pending'
    }
    const total = vote.verified + vote.disputed + vote.false
    const verifiedPercent = (vote.verified / total) * 100
    if (verifiedPercent >= 70) return 'verified'
    if (verifiedPercent <= 30) return 'false'
    return 'disputed'
  }

  const filteredClaims = claims.filter((claim) => {
    if (filter === 'all') return true
    return getStatus(claim.id) === filter
  })

  if (loading) {
    return <div className="py-12 text-center text-muted-foreground">Loading claims...</div>
  }

  return (
    <div className="py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">Verify Claims</h1>
        <div className="flex gap-2 flex-wrap">
          {['all', 'pending', 'verified', 'disputed', 'false'].map((status) => (
            <button
              key={status}
              onClick={() => setFilter(status)}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                filter === status
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {filteredClaims.length === 0 ? (
        <div className="text-center py-12 bg-card rounded-lg border border-border">
          <p className="text-muted-foreground mb-4">No claims to verify in this category.</p>
          <button
            onClick={() => onNavigate('submit')}
            className="px-6 py-2 bg-primary text-primary-foreground rounded-lg font-medium"
          >
            Submit a Claim
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredClaims.map((claim) => (
            <ClaimCard
              key={claim.id}
              claim={claim}
              votes={votes[claim.id] || { claimId: claim.id, verified: 0, disputed: 0, false: 0 }}
              status={getStatus(claim.id)}
              onVote={handleVote}
            />
          ))}
        </div>
      )}
    </div>
  )
}
