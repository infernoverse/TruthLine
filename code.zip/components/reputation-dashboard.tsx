'use client'

import { useState, useEffect } from 'react'

interface ReputationDashboardProps {
  onNavigate: (page: string) => void
}

interface UserProfile {
  name: string
  reputation: number
  verifications: number
  accuracy: number
  moderationActions: number
  joinedAt: number
}

export default function ReputationDashboard({ onNavigate }: ReputationDashboardProps) {
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [username, setUsername] = useState('')
  const [editMode, setEditMode] = useState(false)

  useEffect(() => {
    const saved = localStorage.getItem('currentUser')
    if (saved) {
      setProfile(JSON.parse(saved))
    }
  }, [])

  const handleSetUsername = (name: string) => {
    if (name.trim()) {
      const newProfile: UserProfile = {
        name,
        reputation: 100,
        verifications: 0,
        accuracy: 0,
        moderationActions: 0,
        joinedAt: Date.now(),
      }
      setProfile(newProfile)
      localStorage.setItem('currentUser', JSON.stringify(newProfile))
      setUsername('')
      setEditMode(false)
    }
  }

  const handleUpdateProfile = (updatedFields: Partial<UserProfile>) => {
    if (profile) {
      const newProfile = { ...profile, ...updatedFields }
      setProfile(newProfile)
      localStorage.setItem('currentUser', JSON.stringify(newProfile))
    }
  }

  if (!profile) {
    return (
      <div className="py-12">
        <div className="max-w-2xl mx-auto bg-card p-8 rounded-lg border border-border">
          <h1 className="text-2xl font-bold mb-4">Create Your Profile</h1>
          <div className="space-y-4">
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Choose a username"
              className="w-full px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <button
              onClick={() => handleSetUsername(username)}
              className="w-full px-6 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition"
            >
              Create Profile
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="py-8 max-w-4xl mx-auto">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold">{profile.name}</h1>
          <button
            onClick={() => setEditMode(!editMode)}
            className="px-4 py-2 bg-muted text-muted-foreground rounded-lg hover:bg-muted/80 transition"
          >
            {editMode ? 'Cancel' : 'Edit'}
          </button>
        </div>

        {editMode ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-card p-6 rounded-lg border border-border text-center">
              <input
                type="number"
                value={profile.reputation}
                onChange={(e) => handleUpdateProfile({ reputation: parseInt(e.target.value) })}
                className="w-full px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <div className="text-sm text-muted-foreground">Reputation Points</div>
            </div>
            <div className="bg-card p-6 rounded-lg border border-border text-center">
              <input
                type="number"
                value={profile.verifications}
                onChange={(e) => handleUpdateProfile({ verifications: parseInt(e.target.value) })}
                className="w-full px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <div className="text-sm text-muted-foreground">Verifications</div>
            </div>
            <div className="bg-card p-6 rounded-lg border border-border text-center">
              <input
                type="number"
                value={profile.accuracy}
                onChange={(e) => handleUpdateProfile({ accuracy: parseInt(e.target.value) })}
                className="w-full px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <div className="text-sm text-muted-foreground">Accuracy Rate</div>
            </div>
            <div className="bg-card p-6 rounded-lg border border-border text-center">
              <input
                type="number"
                value={profile.moderationActions}
                onChange={(e) => handleUpdateProfile({ moderationActions: parseInt(e.target.value) })}
                className="w-full px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <div className="text-sm text-muted-foreground">Mod Actions</div>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-card p-6 rounded-lg border border-border text-center">
              <div className="text-3xl font-bold text-primary mb-2">{profile.reputation}</div>
              <div className="text-sm text-muted-foreground">Reputation Points</div>
            </div>
            <div className="bg-card p-6 rounded-lg border border-border text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">{profile.verifications}</div>
              <div className="text-sm text-muted-foreground">Verifications</div>
            </div>
            <div className="bg-card p-6 rounded-lg border border-border text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">{profile.accuracy}%</div>
              <div className="text-sm text-muted-foreground">Accuracy Rate</div>
            </div>
            <div className="bg-card p-6 rounded-lg border border-border text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">{profile.moderationActions}</div>
              <div className="text-sm text-muted-foreground">Mod Actions</div>
            </div>
          </div>
        )}

      </div>

      <div className="bg-card p-6 rounded-lg border border-border">
        <h2 className="text-xl font-bold mb-4">Reputation Levels</h2>
        <div className="space-y-3">
          <div className="flex items-center gap-3 pb-3 border-b border-border">
            <div className="text-2xl">⭐</div>
            <div className="flex-1">
              <p className="font-semibold">Trusted Verifier</p>
              <p className="text-sm text-muted-foreground">50+ reputation points</p>
            </div>
            <span className="text-sm font-mono bg-muted px-3 py-1 rounded">
              {profile.reputation >= 50 ? '✓' : '○'}
            </span>
          </div>
          <div className="flex items-center gap-3 pb-3 border-b border-border">
            <div className="text-2xl">⭐⭐</div>
            <div className="flex-1">
              <p className="font-semibold">Expert Reviewer</p>
              <p className="text-sm text-muted-foreground">100+ reputation points</p>
            </div>
            <span className="text-sm font-mono bg-muted px-3 py-1 rounded">
              {profile.reputation >= 100 ? '✓' : '○'}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-2xl">⭐⭐⭐</div>
            <div className="flex-1">
              <p className="font-semibold">Senior Moderator</p>
              <p className="text-sm text-muted-foreground">250+ reputation points</p>
            </div>
            <span className="text-sm font-mono bg-muted px-3 py-1 rounded">
              {profile.reputation >= 250 ? '✓' : '○'}
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}
