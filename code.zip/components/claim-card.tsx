'use client'

interface ClaimCardProps {
  claim: {
    id: string
    content: string
    source: string
    category: string
    submittedAt: number
    submittedBy: string
  }
  votes: {
    claimId: string
    verified: number
    disputed: number
    false: number
  }
  status: 'pending' | 'verified' | 'disputed' | 'false'
  onVote: (claimId: string, voteType: 'verified' | 'disputed' | 'false') => void
}

export default function ClaimCard({ claim, votes, status, onVote }: ClaimCardProps) {
  const total = votes.verified + votes.disputed + votes.false
  const verifiedPercent = total > 0 ? Math.round((votes.verified / total) * 100) : 0
  const disputedPercent = total > 0 ? Math.round((votes.disputed / total) * 100) : 0
  const falsePercent = total > 0 ? Math.round((votes.false / total) * 100) : 0

  const statusColor = {
    pending: 'bg-yellow-50 dark:bg-yellow-950 border-yellow-200 dark:border-yellow-800',
    verified: 'bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800',
    disputed: 'bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800',
    false: 'bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800',
  }

  const statusLabel = {
    pending: '⏳ Pending',
    verified: '✓ Verified',
    disputed: '⚠️ Disputed',
    false: '✗ False',
  }

  const statusTextColor = {
    pending: 'text-yellow-900 dark:text-yellow-100',
    verified: 'text-green-900 dark:text-green-100',
    disputed: 'text-blue-900 dark:text-blue-100',
    false: 'text-red-900 dark:text-red-100',
  }

  return (
    <div className={`p-6 rounded-lg border ${statusColor[status]}`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <p className="text-sm text-muted-foreground mb-2">
            Reported by <span className="font-semibold">{claim.submittedBy}</span> in {claim.category}
          </p>
          <p className="text-lg leading-relaxed mb-2">{claim.content}</p>
          {claim.source && (
            <a href={claim.source} target="_blank" rel="noopener noreferrer" className="text-sm text-primary hover:underline">
              View source
            </a>
          )}
        </div>
        <span className={`px-3 py-1 rounded-full text-sm font-semibold whitespace-nowrap ml-4 ${statusTextColor[status]}`}>
          {statusLabel[status]}
        </span>
      </div>

      <div className="mb-6">
        <div className="text-xs font-semibold text-muted-foreground mb-2 flex items-center justify-between">
          <span>Community Votes ({total})</span>
          <span className="text-primary font-mono">{verifiedPercent}% | {disputedPercent}% | {falsePercent}%</span>
        </div>
        <div className="flex h-3 gap-1 rounded-full overflow-hidden bg-muted">
          {total > 0 ? (
            <>
              {verifiedPercent > 0 && (
                <div className="bg-green-500" style={{ width: `${verifiedPercent}%` }} />
              )}
              {disputedPercent > 0 && (
                <div className="bg-blue-500" style={{ width: `${disputedPercent}%` }} />
              )}
              {falsePercent > 0 && (
                <div className="bg-red-500" style={{ width: `${falsePercent}%` }} />
              )}
            </>
          ) : (
            <div className="w-full bg-muted-foreground/20" />
          )}
        </div>
      </div>

      <div className="flex gap-2 flex-wrap">
        <button
          onClick={() => onVote(claim.id, 'verified')}
          className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium transition"
        >
          ✓ Verified ({votes.verified})
        </button>
        <button
          onClick={() => onVote(claim.id, 'disputed')}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition"
        >
          ⚠️ Disputed ({votes.disputed})
        </button>
        <button
          onClick={() => onVote(claim.id, 'false')}
          className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition"
        >
          ✗ False ({votes.false})
        </button>
      </div>
    </div>
  )
}
