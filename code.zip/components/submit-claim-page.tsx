'use client'

import { useState, useEffect } from 'react'

interface SubmitClaimPageProps {
  onNavigate: (page: string) => void
}

interface Claim {
  id: string
  content: string
  source: string
  category: string
  submittedAt: number
  submittedBy: string
}

export default function SubmitClaimPage({ onNavigate }: SubmitClaimPageProps) {
  const [content, setContent] = useState('')
  const [source, setSource] = useState('')
  const [category, setCategory] = useState('news')
  const [username, setUsername] = useState('')
  const [submitted, setSubmitted] = useState(false)

  useEffect(() => {
    const saved = localStorage.getItem('currentUser')
    if (saved) {
      setUsername(JSON.parse(saved).name)
    }
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!content.trim() || !username.trim()) {
      alert('Please fill in all fields')
      return
    }

    const newClaim: Claim = {
      id: Date.now().toString(),
      content,
      source,
      category,
      submittedAt: Date.now(),
      submittedBy: username,
    }

    const claims = JSON.parse(localStorage.getItem('claims') || '[]')
    claims.push(newClaim)
    localStorage.setItem('claims', JSON.stringify(claims))

    setSubmitted(true)
    setTimeout(() => {
      setContent('')
      setSource('')
      setCategory('news')
      setSubmitted(false)
      onNavigate('verify')
    }, 2000)
  }

  return (
    <div className="py-8 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Report a Claim</h1>

      {submitted ? (
        <div className="bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg p-6 text-center">
          <div className="text-4xl mb-3">✓</div>
          <p className="text-lg font-semibold text-green-900 dark:text-green-100">
            Claim submitted successfully!
          </p>
          <p className="text-muted-foreground mt-2">
            Redirecting to verification feed...
          </p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6 bg-card p-8 rounded-lg border border-border">
          <div>
            <label className="block text-sm font-medium mb-2">Your Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your username"
              className="w-full px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Claim Content</label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Paste or describe the claim you want to verify..."
              rows={5}
              className="w-full px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <p className="text-xs text-muted-foreground mt-1">
              Be specific and clear about what you're reporting.
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Source URL (optional)</label>
            <input
              type="url"
              value={source}
              onChange={(e) => setSource(e.target.value)}
              placeholder="https://example.com/article"
              className="w-full px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="news">News</option>
              <option value="science">Science</option>
              <option value="politics">Politics</option>
              <option value="health">Health</option>
              <option value="other">Other</option>
            </select>
          </div>

          <button
            type="submit"
            className="w-full px-6 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition"
          >
            Submit for Verification
          </button>
        </form>
      )}
    </div>
  )
}
