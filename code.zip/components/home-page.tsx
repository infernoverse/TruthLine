'use client'

interface HomePageProps {
  onNavigate: (page: string) => void
}

export default function HomePage({ onNavigate }: HomePageProps) {
  return (
    <div className="py-12 space-y-8">
      <section className="text-center py-12 bg-gradient-to-b from-primary/5 to-background rounded-lg">
        <h1 className="text-4xl md:text-5xl font-bold text-balance mb-4">
          Verify the Truth Together
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
          Join our community to report, verify, and crowdsource fact-checking. Trust is built through transparency and collaboration.
        </p>
        <div className="flex gap-4 justify-center flex-wrap">
          <button
            onClick={() => onNavigate('verify')}
            className="px-8 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition"
          >
            Start Verifying
          </button>
          <button
            onClick={() => onNavigate('submit')}
            className="px-8 py-3 bg-secondary text-secondary-foreground rounded-lg font-semibold hover:bg-secondary/90 transition"
          >
            Report a Claim
          </button>
        </div>
      </section>

      <section className="grid md:grid-cols-3 gap-6">
        <div className="bg-card p-6 rounded-lg border border-border">
          <div className="text-3xl mb-3">📊</div>
          <h3 className="font-semibold text-lg mb-2">Trust Scoring</h3>
          <p className="text-muted-foreground">
            Each claim gets scored based on community verification votes and moderator reviews.
          </p>
        </div>
        <div className="bg-card p-6 rounded-lg border border-border">
          <div className="text-3xl mb-3">👥</div>
          <h3 className="font-semibold text-lg mb-2">Peer Moderation</h3>
          <p className="text-muted-foreground">
            Community members with high reputation moderate content and resolve disputes.
          </p>
        </div>
        <div className="bg-card p-6 rounded-lg border border-border">
          <div className="text-3xl mb-3">⭐</div>
          <h3 className="font-semibold text-lg mb-2">Build Reputation</h3>
          <p className="text-muted-foreground">
            Earn reputation points for accurate verifications and helpful contributions.
          </p>
        </div>
      </section>

      <section className="bg-card p-8 rounded-lg border border-border">
        <h2 className="text-2xl font-bold mb-4">How It Works</h2>
        <div className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-semibold">
              1
            </div>
            <div>
              <h4 className="font-semibold">Submit a Claim</h4>
              <p className="text-muted-foreground">Report a statement or article you want verified</p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-semibold">
              2
            </div>
            <div>
              <h4 className="font-semibold">Community Reviews</h4>
              <p className="text-muted-foreground">Other users vote to verify or refute the claim</p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-semibold">
              3
            </div>
            <div>
              <h4 className="font-semibold">Trust Score Calculated</h4>
              <p className="text-muted-foreground">Claim receives a verified, disputed, or false rating</p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-semibold">
              4
            </div>
            <div>
              <h4 className="font-semibold">Moderation Review</h4>
              <p className="text-muted-foreground">Moderators ensure accuracy and prevent abuse</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
