'use client'

import { useState } from 'react'
import Navigation from '@/components/navigation'
import LandingPage from '@/components/landing-page'
import SubmitClaimPage from '@/components/submit-claim-page'
import VerifyClaimsPage from '@/components/verify-claims-page'
import ReputationDashboard from '@/components/reputation-dashboard'
import ModerationPanel from '@/components/moderation-panel'

export default function App() {
  const [currentPage, setCurrentPage] = useState('landing')

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <LandingPage onNavigate={setCurrentPage} />
      case 'submit':
        return <SubmitClaimPage onNavigate={setCurrentPage} />
      case 'verify':
        return <VerifyClaimsPage onNavigate={setCurrentPage} />
      case 'reputation':
        return <ReputationDashboard onNavigate={setCurrentPage} />
      case 'moderate':
        return <ModerationPanel onNavigate={setCurrentPage} />
      default:
        return <LandingPage onNavigate={setCurrentPage} />
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation currentPage={currentPage} onNavigate={setCurrentPage} />
      {renderPage()}
    </div>
  )
}
